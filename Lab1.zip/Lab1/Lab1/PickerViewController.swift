//
//  PickerViewController.swift
//  Lab1
//
//  Created by loaner on 9/8/23.
//

import UIKit

class PickerViewController: UIViewController {

    @IBOutlet weak var profilePicker: UIPickerView!
    @IBOutlet weak var pickerLabel: UILabel!
    
    @IBOutlet weak var profileSegment: UISegmentedControl!
    @IBOutlet weak var segmentLabel: UILabel!
    @IBOutlet weak var avatarView: UIImageView!
    
    let profiles = ["Fit Master", "Quad King", "Super Strong", "Elegant Elephant","Derik"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        pickerLabel.text = " "
        
        profilePicker.delegate = self
        profilePicker.dataSource = self
        
        avatarView.image = UIImage(named: "profile1")
        
    }
    @IBAction func switchSegmentControl(_ sender: Any) {
        
        switch profileSegment.selectedSegmentIndex{
        case 0:
            avatarView.image = UIImage(named: "profile1")
            
            break
        case 1:
            avatarView.image = UIImage(named: "profile2")
            break
        case 2:
            avatarView.image = UIImage(named: "profile3")
            break
        case 3:
            avatarView.image = UIImage(named: "profile4")
            break
        default:
            break
        }
    }
    
}

extension PickerViewController: UIPickerViewDelegate, UIPickerViewDataSource
{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return profiles.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return profiles[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        pickerLabel.text = profiles[row]
    }
    
}
